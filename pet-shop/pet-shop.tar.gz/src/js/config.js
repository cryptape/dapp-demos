window.config = {
    chain: 'http://121.196.200.225:1337',
    privateKey: '0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee',  // your private key
}
